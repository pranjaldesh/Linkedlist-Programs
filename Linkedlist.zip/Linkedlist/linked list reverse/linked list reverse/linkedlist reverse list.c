//REVERSE A LINKED LIST
#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node* next;
};
struct node* createnode()
{
	int x;
	struct node* newnode=NULL;
	newnode=(struct node*)malloc(sizeof(struct node));
	if(newnode==NULL)
	{
		printf("Memory not allocated");
		return NULL;
	}
	else
	{
		printf("Enter a data");
		scanf("%d",&x);
		newnode->data=x;
		newnode->next=NULL;
		return newnode;
	}
}
void createlinkedlist(struct node** head)
{
	struct node* newnode=NULL;
	struct node* travenode=*head;
	newnode=createnode();
	if(*head==NULL)
	{
		*head=newnode;
	}
	else
	{
		while(travenode->next!=NULL)
		{
			travenode=travenode->next;
		}
		travenode->next=newnode;
	}
}
void reverselinkedlist(struct node** head)
{
	struct node* prevnode=NULL;
	struct node* currentnode=*head;
	struct node* nextnode=*head;
	while(nextnode!=NULL)
	{
		nextnode=nextnode->next;
		currentnode->next=prevnode;
		prevnode=currentnode;
		currentnode=nextnode;
	}
	*head=prevnode;
}
void displaylinkedlist(struct node* head)
{
	if(head==NULL)
	{
		printf("Linked list not exist");
	}
	else
	{
		while(head!=NULL)
		{
			printf("%d->",head->data);
			head=head->next;
		}
		printf("\n");
	}
}
void main()
{
	int choices;
	struct node* first=NULL;
	do
	{
		printf("1.Createlinkedlist\n");
		printf("2.Displaylinkedlist\n");
		printf("3.Reverselinkedlist\n");
		printf("4.Displayreverselinkedlist\n");
		printf("5.Exit\n");
		printf("please Enter your choice");
		scanf("%d",&choices);

		switch(choices)
		{
		case 1:createlinkedlist(&first);
			break;
		case 2:displaylinkedlist(first);
			break;
		case 3:reverselinkedlist(&first);
			break;
		case 4:displaylinkedlist(first);
			break;

		}
	}while(choices!=5);
}

