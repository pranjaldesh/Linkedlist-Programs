#include<stdio.h>
void merge(int array[],int low,int mid,int high)
{
    int barray[10],i,j,k=0;
    i=low;
    j=mid+1;
    while(i<=mid && j<=high)
    {
        if(array[i]<array[j])
        {
            barray[k]=array[i];
            k++;
            i++;
        }
        else
        {
            barray[k]=array[j];
            k++;
            j++;
        }
        
    }
    while(i<=mid)
    {
        barray[k]=array[i];
        k++;
        i++;
    }
    while(j<=high)
    {
        barray[k]=array[j];
        k++;
        j++;
    }
    k=0;
    for(i=low;i<=high;i++)
    {
        array[i]=barray[k];
        k++;
    }
}
void mergesort(int array[],int low,int high)
{
    if(low<high)
    {
        int mid;
        mid=(low+high)/2;
        mergesort(array,low,mid);
        mergesort(array,mid+1,high);
        merge(array,low,mid,high);
    }
}
void main()
{
    int array[10],i,n;
    printf("plz enter no.of element u want to insert:-");
    scanf("%d",&n);
    printf("Enter array elements:-");
    for(i=0;i<n;i++)
    {
        scanf("%d",&array[i]);
    }
    printf("Unsorted array is :-");
    printf("[");
    for(i=0;i<n;i++)
    {
        printf("%d, ",array[i]);
    }
    printf("]\n");
    mergesort(array,0,n-1);
    printf("Sorted array is :-");
    printf("[");
    for(i=0;i<n;i++)
    {
        printf("%d, ",array[i]);
    }
    printf("]\n");
}