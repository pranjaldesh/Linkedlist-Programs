#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node* next;
};
struct node* createnode()
{
	int x;
	struct node* newnode=NULL;
	newnode=((struct node*)malloc(sizeof(struct node)));
	if(newnode==NULL)
	{
		printf("memory not allocated");
		return NULL;
	}
	else
	{
		printf("Enter a data");
		scanf("%d",&x);
		newnode->data=x;
		newnode->next=NULL;
		return newnode;
	}
}
void createlinkedlist(struct node** head)
{
	struct node* newnode=NULL;
	struct node* travenode=*head;
	newnode=createnode();
	if(*head==NULL)
	{
		*head=newnode;
	}
	else
	{
		while(travenode->next!=NULL)
		{
			travenode=travenode->next;
		}
		newnode->next=travenode->next;
		travenode->next=newnode;
	}
}
void displaylinkedlist(struct node* head)
{
	if(head==NULL)
	{
		printf("Linked list not exist\n");
	}
	else
	{
		while(head!=NULL)
		{
			printf("%d->",head->data);
			head=head->next;
		}
	
	}
}
void EvenOdd_Linked_List(struct node* head,struct node** head1,struct node** head2)
	{
		printf("Even and Odd Linked List Created\n");
	while(head!=NULL)
	{
		if(head->data%2==0)
		{
			struct node* newnode_A=NULL;
			struct node* tempnode=*head1;
			newnode_A=(struct node*)malloc(sizeof(struct node));
			newnode_A->data=head->data;
			newnode_A->next=NULL;
			if(*head1==NULL)
			{
				*head1=newnode_A;
			}
			else
			{
				while(tempnode->next!=NULL)
				{
					tempnode=tempnode->next;
				}
				tempnode->next=newnode_A;
			}
		}
		else
		{
			struct node* newnode_B=NULL;
			struct node* tempnode=*head2;
			newnode_B=(struct node*)malloc(sizeof(struct node));
			newnode_B->data=head->data;
			newnode_B->next=NULL;
			if(*head2==NULL)
			{
				*head2=newnode_B;
			}
			else
			{
				while(tempnode->next!=NULL)
				{
					tempnode=tempnode->next;
				}
				tempnode->next=newnode_B;
			}
		}
		head=head->next;
	}
}

void main()
{
	int choice;
	struct node* first=NULL;
	struct node* even=NULL;
	struct node* odd=NULL;
	do
	{
	printf("\n1.Create linked list\n");
	printf("2.Dispaly linked list\n");
	printf("3.Create Even-Odd linked list\n");
	printf("4.Dispaly Even linked list\n");
	printf("5.Dispaly Odd linked list\n");
	printf("6.Exit\n");
	printf("Please enter ur choice\n");
	scanf("%d",&choice);
	switch(choice)
	{
	case 1:createlinkedlist(&first);
		break;
	case 2:displaylinkedlist(first);
		break;
	case 3:EvenOdd_Linked_List(first,&even,&odd);
		break;
	case 4:displaylinkedlist(even);
		break;
	case 5:displaylinkedlist(odd);
		break;

	}
	}while(choice!=6);
}