#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node* next;
};
struct node* createnode()
{
	int x;
	struct node* newnode=NULL;
	newnode=((struct node*)malloc(sizeof(struct node)));
	if(newnode==NULL)
	{
		printf("memory not allocated");
		return NULL;
	}
	else
	{
		printf("Enter a data");
		scanf("%d",&x);
		newnode->data=x;
		newnode->next=NULL;
		return newnode;
	}
}
void createlinkedlist(struct node** head)
{
	struct node* newnode=NULL;
	struct node* travenode=*head;
	newnode=createnode();
	if(*head==NULL)
	{
		*head=newnode;
	}
	else
	{
		while(travenode->next!=NULL)
		{
			travenode=travenode->next;
		}
		newnode->next=travenode->next;
		travenode->next=newnode;
	}
}
void displaylinkedlist(struct node* head)
{
	if(head==NULL)
	{
		printf("linked list not exist");
	}
	else
	{
		while(head!=NULL)
		{
			printf("%d->",head->data);
			head=head->next;
		}
		printf("\n");
	}
}
void searchdata(struct node* head,int x)
{
	printf("enter a data to be searched");
	scanf("%d",&x);
	while(head!=NULL)
	{
		if(head->data==x)
		{

		printf("%d Data found\n",x);	
		break;
		}
		else
		{
		head=head->next;
		}
	}
	printf("%d Data Not Found\n",x);
}

void main()
{
	int choice,key=0;
	struct node* first=NULL;
	do
	{
	printf("1.Create linked list\n");
	printf("2.Dispaly linked list\n");
	printf("3.Search a data\n");
	
	printf("4.Exit\n");
	printf("Please enter ur choice\n");
	scanf("%d",&choice);
	switch(choice)
	{
	case 1:createlinkedlist(&first);
		break;
	case 2:displaylinkedlist(first);
		break;
	case 3:searchdata(first,key);
		break;
	}
	}while(choice!=4);
}