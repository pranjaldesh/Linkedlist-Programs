#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node* next;
};
struct node* createnode()
{
	int x;
	struct node* newnode=NULL;
	newnode=(struct node*)malloc(sizeof(struct node));
	if(newnode==NULL)
	{
		printf("Memory not allocated");
		return NULL;
	}
	else
	{
		printf("Please Enter a data");
		scanf("%d",&x);
		newnode->data=x;
		newnode->next=NULL;
		return newnode;
	}
}
void createlinkedlist(struct node** head)
{
	struct node* tempnode=*head;
	struct node* newnode=NULL;
	newnode=createnode();
	if(*head==NULL)
	{
		*head=newnode;
	}
	else
	{
		while(tempnode->next!=NULL)
		{
			tempnode=tempnode->next;
		}
		tempnode->next=newnode;
	}
}
void displaylinkedlist(struct node* head)
{
	if(head==NULL)
	{
		printf("Linked list not exist");
	}
	else
	{
		while(head!=NULL)
		{
			printf("%d->",head->data);
			head=head->next;
		}
	}
}
void deleteatfirst(struct node** head)
{
	if(*head==NULL)
	{
		printf("Linked list not exist\n");
	}
	else
	{
		struct node* tempnode=*head;
		*head=(*head)->next;
		free(tempnode);
	}
}
void deletegivennode(struct node** head)
{
struct node* tempnode=NULL;
struct node* tempnode1=NULL;
int x;
printf("Please enter a data to be delete\n");
scanf("%d",&x);
if(*head==NULL)
{
	printf("Linked list not exist\n");
}
else if( ((*head)->data)==x)
{
	deleteatfirst(head);
}
else
{
	tempnode=*head;
	while(tempnode->next->next!=NULL)
	{
		if((tempnode->next->data)==x)
			break;
		else
			tempnode=tempnode->next;
	}
	tempnode1=tempnode->next;
	tempnode->next=tempnode->next->next;
	free(tempnode1);
}
}
void main()
{
	int choices;
	struct node* first=NULL;
	do
	{
		printf("1.create linked list\n");
		printf("2.display linked list\n");
		printf("3.Delete at first\n");
		printf("4.Delete a given node\n");
		printf("5.Exist\n");

		printf("plz enter your choice");
		scanf("%d",&choices);
		switch(choices)
		{
		case 1:createlinkedlist(&first);
			break;
		case 2:displaylinkedlist(first);
			break;
		case 3:deleteatfirst(&first);
			break;
		case 4:deletegivennode(&first);
			break;
		}
	}while(choices!=5);
	printf("Thank You!");
}