#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node* next;
};
struct node* createnode()
{
	int x;
	struct node* newnode=NULL;
	newnode=((struct node*)malloc(sizeof(struct node)));
	if(newnode==NULL)
	{
		printf("memory not allocated");
		return NULL;
	}
	else
	{
		printf("Enter a data");
		scanf("%d",&x);
		newnode->data=x;
		newnode->next=NULL;
		return newnode;
	}
}
void createlinkedlist(struct node** head)
{
	struct node* newnode=NULL;
	struct node* travenode=*head;
	newnode=createnode();
	if(*head==NULL)
	{
		*head=newnode;
	}
	else
	{
		while(travenode->next!=NULL)
		{
			travenode=travenode->next;
		}
		newnode->next=travenode->next;
		travenode->next=newnode;
	}
}
void displaylinkedlist(struct node* head)
{
	if(head==NULL)
	{
		printf("Linked list not exist\n");
	}
	else
	{
		while(head!=NULL)
		{
			printf("%d->",head->data);
			head=head->next;
		}
	
	}
}

void Armstrong_Number(struct node* head)
	{
		int i,r,sum=0,count=0,temp,multiply=1;
		while(head!=NULL)
		{
			sum=0;
			count=0;
			temp=head->data;
			while(temp!=0)
			{
				temp=temp/10;
				count++;
			}
			temp=head->data;
			while(temp!=0)
			{
				r=temp%10;
				temp=temp/10;
				multiply=1;
				for(i=0;i<count;i++)
				{
				multiply=multiply*r;
				}
				sum=sum+multiply;
				
			}
			if(sum==(head->data))
			printf("%d->",(head->data));
			head=head->next;	
		}
}
void main()
{
	int choice;
	struct node* first=NULL;
	do
	{
	printf("\n1.Create linked list\n");
	printf("2.Dispaly linked list\n");
	printf("3.Search Armstrong Number\n");
	printf("4.Exit\n");
	printf("Please enter ur choice\n");
	scanf("%d",&choice);
	switch(choice)
	{
	case 1:createlinkedlist(&first);
		break;
	case 2:displaylinkedlist(first);
		break;
	case 3:Armstrong_Number(first);
		break;
	}
	}while(choice!=4);
}