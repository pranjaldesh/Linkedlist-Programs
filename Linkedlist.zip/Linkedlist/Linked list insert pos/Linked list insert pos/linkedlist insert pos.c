//REVERSE A LINKED LIST
#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node* next;
};
struct node* createnode()
{
	int x;
	struct node* newnode=NULL;
	newnode=(struct node*)malloc(sizeof(struct node));
	if(newnode==NULL)
	{
		printf("Memory not allocated");
		return NULL;
	}
	else
	{
		printf("Enter a data");
		scanf("%d",&x);
		newnode->data=x;
		newnode->next=NULL;
		return newnode;
	}
}
void createlinkedlist(struct node** head)
{
	struct node* newnode=NULL;
	struct node* travenode=*head;
	newnode=createnode();
	if(*head==NULL)
	{
		*head=newnode;
	}
	else
	{
		while(travenode->next!=NULL)
		{
			travenode=travenode->next;
		}
		travenode->next=newnode;
	}
}

void displaylinkedlist(struct node* head)
{
	if(head==NULL)
	{
		printf("Linked list not exist");
	}
	else
	{
		while(head!=NULL)
		{
			printf("%d->",head->data);
			head=head->next;
		}
		printf("\n");
	}
}
void insertatfirst(struct node** head)
{

}
void insertatlast(struct node** head)
{
	createlinkedlist(head);
}
void insertatposition(struct node** head)
{


}
void main()
{
	int choices;
	struct node* first=NULL;
	do
	{
		printf("1.Createlinkedlist\n");
		printf("2.Displaylinkedlist\n");
		printf("3.Insert at first\n");
		printf("4.Insert at last\n");
		printf("5.Inser at position\n");
		printf("6.Exit\n");
		printf("please Enter your choice");
		scanf("%d",&choices);

		switch(choices)
		{
		case 1:createlinkedlist(&first);
			break;
		case 2:displaylinkedlist(first);
			break;
		case 3:insertatfirst(&first);
			break;
		case 4:insertatlast(&first);
			break;
		case 5:insertatposition(&first);
			break;

		}
	}while(choices!=6);
}

