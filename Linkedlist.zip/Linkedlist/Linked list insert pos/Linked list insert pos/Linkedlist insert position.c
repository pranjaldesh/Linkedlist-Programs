#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node* next;
};
struct node* createnode()
{
	int x;
	struct node* newnode=NULL;
	newnode=(struct node*)malloc(sizeof(struct node));
	if(newnode==NULL)
	{
		printf("Memory not allocated\n");
		return NULL;
	}
	else
	{
		printf("plz enter a data\n");
		scanf("%d",&x);
		newnode->data=x;
		newnode->next=NULL;
		return newnode;
	}
}
void createlinkedlist(struct node** head)
{
struct node* newnode=NULL;
struct node* tempnode=*head;
newnode=createnode();
if(*head==NULL)
{
	*head=newnode;
}
else
{
	while(tempnode->next!=NULL)
	{
		tempnode=tempnode->next;
	}
	tempnode->next=newnode;
}
}
void displaylinkedlist(struct node* head)
{
	if(head==NULL)
	{
		printf("Linked list not exist\n");
	}
	else
	{
		while(head!=NULL)
		{
			printf("%d->",head->data);
			head=head->next;
		}
	}
}
void insertatfirst(struct node** head)
{
	struct node* newnode=NULL;
	newnode=createnode();
	newnode->next=*head;
	*head=newnode;
}
void insertatlast(struct node** head
{
createlinkedlist(head);
}
int countnodes(struct node* head
{
int count=0;
while(head!=NULL)
{
	count++;
	head=head->next;
}
return count;
}
void insertatposition(struct node** head)
{
int position,no_of_nodes,i;
struct node* newnode=NULL;
struct node* tempnode=*head;
printf("Enter a position\n");
scanf("%d",&position);
no_of_nodes=countnodes(*head);
if(position==1)
{
	insertatfirst(head);
}
else if(position==(no_of_nodes+1))
{
	insertatlast(head);
}
else if(position<1||position>(no_of_nodes+1))
{
	printf("Invalid positon\n");
	insertatposition(head);
}
else
{
	newnode=createnode();
	for(i=1;i<position-1;i++);
	{
		tempnode=tempnode->next;
	}
	newnode->next=tempnode->next;
	tempnode->next=newnode;
}
}
void main()
{
	int choices;
	struct node* first=NULL;
	do
	{
		printf("\nCreate a linked list\n");
		printf("Display a linked list\n");
		printf("Insert at first\n");
		printf("Insert at last\n");
		printf("Insert at position\n");
		printf("Exit");

		printf("plz enter your choice");
		scanf("%d",&choices);
		 switch(choices)
		 {
		 case 1:createlinkedlist(&first);
			 break;
		 case 2:displaylinkedlist(first);
			 break;
		 case 3:insertatfirst(&first);
			 break;
		 case 4:insertatlast(&first);
			 break;
		 case 5:insertatposition(&first);
			 break;
		 }
	}while(choices!=6);
	printf("Thank you");
}
























































}