#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node* next;
};
struct node* createnode()
{
	int x;
	struct node* newnode=NULL;
	newnode=((struct node*)malloc(sizeof(struct node)));
	if(newnode==NULL)
	{
		printf("memory not allocated");
		return NULL;
	}
	else
	{
		printf("Enter a data");
		scanf("%d",&x);
		newnode->data=x;
		newnode->next=NULL;
		return newnode;
	}
}
void createlinkedlist(struct node** head)
{
	struct node* newnode=NULL;
	struct node* travenode=*head;
	newnode=createnode();
	if(*head==NULL)
	{
		*head=newnode;
	}
	else
	{
		while(travenode->next!=NULL)
		{
			travenode=travenode->next;
		}
		newnode->next=travenode->next;
		travenode->next=newnode;
	}
}
void displaylinkedlist(struct node* head)
{
	if(head==NULL)
	{
		printf("Linked list not exist\n");
	}
	else
	{
		while(head!=NULL)
		{
			printf("%d->",head->data);
			head=head->next;
		}
	
	}
}
void Sort_Even_Linked_List(struct node* head,struct node** head1)
{
		printf("Even Linked List Created\n");
	while(head!=NULL)
	{
		if(head->data%2==0)
		{
			struct node* newnode=NULL;
			struct node* tempnode=*head1;
			newnode=(struct node*)malloc(sizeof(struct node));
			newnode->data=head->data;
			newnode->next=NULL;
			if(*head1==NULL)
			{
				*head1=newnode;
			}
			else
			{
				while(tempnode->next!=NULL)
				{
					tempnode=tempnode->next;
				}
				tempnode->next=newnode;
			}
		}
		
		head=head->next;
	}
}

void main()
{
	int choice;
	struct node* first=NULL;
	struct node* even=NULL;
	do
	{
	printf("\n1.Create linked list\n");
	printf("2.Dispaly linked list\n");
	printf("3.Sort Even linked list\n");
	printf("4.Dispaly Even linked list\n");
	printf("5.Exit\n");
	printf("Please enter ur choice\n");
	scanf("%d",&choice);
	switch(choice)
	{
	case 1:createlinkedlist(&first);
		break;
	case 2:displaylinkedlist(first);
		break;
	case 3:Sort_Even_Linked_List(first,&even);
		break;
	case 4:displaylinkedlist(even);
		break;
	}
	}while(choice!=5);
}