#include<stdio.h>
#include<stdlib.h>
struct node
{
	char str[100];
	struct node* next;
};
struct node* createnode()
{
	struct node* newnode=NULL;
	newnode=(struct node*)malloc(sizeof(struct node));
	if(newnode==NULL)
	{
		printf("Memory Not Allocated");
		return NULL;
	}
	else
	{
		printf("Enter a string");
		scanf("%s",(newnode->str));
		newnode->next=NULL;
		return newnode;
	}
}
void createlinkedlist(struct node** head)
{
	struct node* newnode=NULL;
	struct node* travenode=*head;
	newnode=createnode();
	if(*head==NULL)
	{
		*head=newnode;
	}
	else
	{
		while(travenode->next!=NULL)
		{
			travenode=travenode->next;
		}
		travenode->next=newnode;
	}
}
void display(struct node* head)
{	
	int i=0;
	if(head==NULL)
	{
		printf("Linked list not exist\n");
	}
	else
	{
		while(head!=NULL)
		{
			while(head->str[i]!='\0')
			{
				printf("%c",head->str[i]);
				i++;
			}
			printf(" ");
			head=head->next;
		}
			
	}
}

void main()
{
	int choices;
	struct node* first=NULL;
	do
	{
	printf("1.Create linked list\n");
	printf("2.Display linked list\n");
	printf("3.Exit\n");
	printf("Enter your choice");
	scanf("%d",&choices);
	switch(choices)
	{
	case 1:createlinkedlist(&first);
		break;
	case 2:display(first);
		break;
	}
	}while(choices!=3);
	printf("Thank You");
}
