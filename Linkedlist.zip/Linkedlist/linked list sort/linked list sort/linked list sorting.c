//SORT A LINKED LIST IN ASCENDING ORDER
#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node* next;
};
struct node* createnode()
{
	int x;
	struct node* newnode=NULL;
	newnode=((struct node*)malloc(sizeof(struct node)));
	if(newnode==NULL)
	{
		printf("memory not allocated");
		return NULL;
	}
	else
	{
		printf("Enter a data");
		scanf("%d",&x);
		newnode->data=x;
		newnode->next=NULL;
		return newnode;
	}
}
void createlinkedlist(struct node** head)
{
	struct node* newnode=NULL;
	struct node* travenode=*head;
	newnode=createnode();
	if(*head==NULL)
	{
		*head=newnode;
	}
	else
	{
		while(travenode->next!=NULL)
		{
			travenode=travenode->next;
		}
		newnode->next=travenode->next;
		travenode->next=newnode;
	}
}

void sortlinkedlist(struct node** head)
{
	int temp;
	struct node* tempnode1=*head;
	struct node* tempnode2=NULL;
	if(*head==NULL)
	{
		printf("Linked list not exist");
	}
	else
	{
	printf("I will Display Sorted Linked List After u choose choise no. 4\n");
	while(tempnode1!=NULL)
		{
		tempnode2=tempnode1->next;
			while(tempnode2!=NULL)
			{
				if(tempnode1->data>tempnode2->data)
					{
						temp=tempnode1->data;
						tempnode1->data=tempnode2->data;
						tempnode2->data=temp;
					}
				tempnode2=tempnode2->next;
			}	
			tempnode1=tempnode1->next;	
		}
	}
}
void displaylinkedlist(struct node* head)
{
	if(head==NULL)
	{
		printf("linked list not exist");
	}
	else
	{
		printf("Linked List\n");
		printf("\n");
		while(head!=NULL)
	{
		printf("%d->",head->data);
		head=head->next;
	}
		printf("\n");
	}
}
void main()
{
	int choice;
	struct node* first=NULL;
	do
	{
	printf("\n");
	printf("1.Create linked list\n");
	printf("2.Display Original linked list\n");
	printf("3.Sort linked list\n");
	printf("4.Display Sorted linked list\n");
	printf("5.Exit\n");
	printf("Please enter ur choice\n");
	scanf("%d",&choice);
	switch(choice)
	{
	case 1:createlinkedlist(&first);
		break;
	case 2:displaylinkedlist(first);
		break;
	case 3:sortlinkedlist(&first);
		break;
	case 4:displaylinkedlist(first);
		break;
	}
	}while(choice!=6);
}