#include<stdio.h>
void display(int array[],int n)
{
    int i;
    printf("[");
    for(i=0;i<n;i++)
    {
        printf("%d, ",array[i]);
    }
    printf("]");
}
void bubble_sort(int array[],int n)
{
    int i,temp,itr,sort;
    for(itr=1;itr<n;itr++)
    {
        
        sort=0;
        for(i=0;i<n-itr;i++)
        {
            printf("Comparision Between:-[%d,%d]\n",array[i],array[i+1]);
            if(array[i]>array[i+1])
            {
                sort=1;
                temp=array[i];
                array[i]=array[i+1];
                array[i+1]=temp;
                 printf("Swapped Elements:-[%d,%d]\n",array[i],array[i+1]);
            }
        }
        printf("Iteration:-%d\n",itr);
        display(array,n);
        printf("\n");
        if(sort==0)
        {
            break;
        }
    }
}

int main()
{
    int array[10],i,n;
    printf("Please enter no.of element u want to insert:-");
    scanf("%d",&n);
    printf("Please enter array elements:-");
    for(i=0;i<n;i++)
    {
        scanf("%d",&array[i]);
    }
    printf("Unsorted Array is:-\n");
    display(array,n);
    bubble_sort(array,n);
    printf("\nSorted Array is:-\n");
    display(array,n);
}