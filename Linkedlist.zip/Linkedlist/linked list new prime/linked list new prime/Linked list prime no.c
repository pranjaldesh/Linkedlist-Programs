#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node* next;
};


void displayprimedata(struct node* head)
{
	int number,i;
	for(number=2;number<1000;number++)
	{
		for(i=2;i<number;i++)
		{
			if(number%2==0)
			break;
		}
		if(i==number)
			printf("%d->",number);
	}

}

void main()
{
	int choices;
	struct node* first=NULL;
	do
	{
		
		printf("\n1.Display Prime Data\n");
		printf("2.Exist\n");

		printf("plz enter your choice");
		scanf("%d",&choices);
		switch(choices)
		{
		case 1:displayprimedata(first);
			break;
		}
	}while(choices!=2);
	printf("Thank You!");
}