#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node* next;
};
struct node* createnode()
{
	int x;
	struct node* newnode=NULL;
	newnode=((struct node*)malloc(sizeof(struct node)));
	if(newnode==NULL)
	{
		printf("memory not allocated");
		return NULL;
	}
	else
	{
		printf("Enter a data");
		scanf("%d",&x);
		newnode->data=x;
		newnode->next=NULL;
		return newnode;
	}
}
void createlinkedlist_1(struct node** head1)
{
	struct node* newnode=NULL;
	struct node* travenode=*head1;
	newnode=createnode();
	if(*head1==NULL)
	{
		*head1=newnode;
	}
	else
	{
		while(travenode->next!=NULL)
		{
			travenode=travenode->next;
		}
		newnode->next=travenode->next;
		travenode->next=newnode;
	}
}
void displaylinkedlist_1(struct node* head1)
{
	if(head1==NULL)
	{
		printf("linked list not exist");
	}
	else
	{
		while(head1!=NULL)
		{
			printf("%d->",head1->data);
			head1=head1->next;
		}
		printf("\n");
	}
}
void createlinkedlist_2(struct node** head2)
{
	struct node* newnode=NULL;
	struct node* travenode=*head2;
	newnode=createnode();
	if(*head2==NULL)
	{
		*head2=newnode;
	}
	else
	{
		while(travenode->next!=NULL)
		{
			travenode=travenode->next;
		}
		newnode->next=travenode->next;
		travenode->next=newnode;
	}
}
void displaylinkedlist_2(struct node* head2)
{
	if(head2==NULL)
	{
		printf("linked list not exist");
	}
	else
	{
		while(head2!=NULL)
		{
			printf("%d->",head2->data);
			head2=head2->next;
		}
		printf("\n");
	}
}

void merge(struct node* head1,struct node* head2)
{
	struct node* ptr=NULL;
		ptr=head1;
		while(ptr->next!=NULL)
		{
			ptr=ptr->next;
		}
		ptr->next=head2;
}
void displayMergedlinkedlist(struct node* head1)
{
	if(head1==NULL)
	{
		printf("linked list not exist\n");
	}
	else
	{
		while(head1!=NULL)
		{
			printf("%d->",head1->data);
			head1=head1->next;
		}
		printf("\n");
	}
}
void main()
{
	int choice;
	struct node* first1=NULL;
	struct node* first2=NULL;
	do
	{
	printf("1.Create linked list_1\n");
	printf("2.Dispaly linked list_1\n");
	printf("3.Create linked list_2\n");
	printf("4.Dispaly linked list_2\n");
	printf("5.Merge linked list\n");
	printf("6.Display Merged linked list\n");
	printf("7.Exit\n");
	printf("Please enter ur choice\n");
	scanf("%d",&choice);
	switch(choice)
	{
	case 1:createlinkedlist_1(&first1);
		break;
	case 2:displaylinkedlist_1(first1);
		break;
	case 3:createlinkedlist_2(&first2);
		break;
	case 4:displaylinkedlist_2(first2);
		break;
	case 5:merge(first1,first2);
		break;
	case 6:displayMergedlinkedlist(first1);
		break;
	}
	}while(choice!=7);
}