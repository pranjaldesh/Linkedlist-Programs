#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node* next;
};
struct node* createnode()
{
	int x;
	struct node* newnode=NULL;
	newnode=(struct node*)malloc(sizeof(struct node));
	if(newnode==NULL)
	{
		printf("Memory not allocated");
		return NULL;
	}
	else
	{
		printf("Please Enter a data");
		scanf("%d",&x);
		newnode->data=x;
		newnode->next=NULL;
		return newnode;
	}
}
void createlinkedlist(struct node** head)
{
	struct node* tempnode=*head;
	struct node* newnode=NULL;
	newnode=createnode();
	if(*head==NULL)
	{
		*head=newnode;
	}
	else
	{
		while(tempnode->next!=NULL)
		{
			tempnode=tempnode->next;
		}
		tempnode->next=newnode;
	}
}
void displaylinkedlist(struct node* head)
{
	if(head==NULL)
	{
		printf("Linked list not exist");
	}
	else
	{
		while(head!=NULL)
		{
			printf("%d->",head->data);
			head=head->next;
		}
	}
}

void displayevendata(struct node* head)
{
	int count=0;
if(head==NULL)
{
	printf("Linked list not exist\n");
}
else
{
	while(head!=NULL)
	{
		count++;
		if(count%2==0)
		{
			printf("%d->",head->data);
		}
		head=head->next;
	}
	
}

}

void main()
{
	int choices;
	struct node* first=NULL;
	do
	{
		printf("\n1.create linked list\n");
		printf("2.display linked list\n");
		printf("3.Display Even Data\n");
		printf("4.Exist\n");

		printf("plz enter your choice");
		scanf("%d",&choices);
		switch(choices)
		{
		case 1:createlinkedlist(&first);
			break;
		case 2:displaylinkedlist(first);
			break;
		case 3:displayevendata(first);
			break;
		}
	}while(choices!=4);
	printf("Thank You!");
}