#include<stdio.h>
#include<stdlib.h>
struct node
{
	char name[100];
	char rollno[100];
	int marks[100];
	struct node* next;
};
struct node* createnode()
{
	int i;
	struct node* newnode=NULL;
	newnode=(struct node*)malloc(sizeof(struct node));
	for(i=0;i<5;++i)
	{
	printf("Enter Name\n");
	scanf("%s\n",(newnode->name[i]));
	printf("Enter Roll no.\n");
	scanf("%s\n",(newnode->rollno[i]));
	printf("Enter Marks\n");
	scanf("%f\n",&(newnode->marks[i]));
	newnode->next=NULL;
	}
	return newnode;
}
void createlinkedlist(struct node** head)
{
	
	struct node* newnode=NULL;
	struct node* travenode=*head;
	newnode=createnode();
	if(*head==NULL)
	{
		*head=newnode;
	}
	else
	{
		while(travenode->next!=NULL)
		{
			travenode=travenode->next;
		}
		travenode->next=newnode;
	}
}
void display(struct node* head)
{	
	int i;
	if(head==NULL)
	{
		printf("Linked list not exist\n");
	}
	else
	{
		while(head!=NULL)
		{
			for(i=0;i<5;i++)
			{
			printf("%s->",(head->name[i]));
			printf("%s->",(head->rollno[i]));
			printf("%f->",(head->marks[i]));
			head=head->next;
			}
		}
			
	}
}

void main()
{
	int choices;
	struct node* first=NULL;
	do
	{
	printf("1.Create linked list\n");
	printf("2.Display linked list\n");
	printf("3.Exit\n");
	printf("Enter your choice");
	scanf("%d",&choices);
	switch(choices)
	{
	case 1:createlinkedlist(&first);
		break;
	case 2:display(first);
		break;
	}
	}while(choices!=3);
	printf("Thank You");
}
