#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node* next;
};
struct node* createnode()
{
	int x;
	struct node* newnode=NULL;
	newnode=(struct node*)malloc(sizeof(struct node));
	if(newnode==NULL)
	{
		printf("Memory not allocated");
		return NULL;
	}
	else
	{
		printf("Please Enter the data");
		scanf("%d",&x);
		newnode->data=x;
		newnode->next=NULL;
		return newnode;
	}
}
void createlinkedlist(struct node** head)
{
	struct node* newnode=NULL;
	struct node* travnode=*head;
	newnode=createnode();
	if(*head==NULL)
	{
		*head=newnode;
	}
	else
	{
		while(travnode->next!=NULL)
		{
			travnode=travnode->next;
		}
		travnode->next=newnode;
	}
}

void displaylinkedlist(struct node* head)
{
	if(head==NULL)
	{
		printf("Linked list not exists");
		return;
	}
	else
	{
		while(head!=NULL)
		{
			printf("%d ->",head->data);
			head=head->next;
		}
	}
}
void primenumber(struct node* head)
{
	int number,i,flag=0;
	while(head!=NULL)
	{
	for(i=1;i<=1000;i++)
	{
		if(i%i==0)
		{
			flag=1;
		}
	}
	}
}

void main()
{
	int choice;
	struct node* first=NULL;
	do
	{
	printf("1.Create linked list\n");
	printf("2.Display linked list\n");
	printf("3.Prime Number\n");
	printf("4.Exit\n");

	printf("Enter Your Choice\n");
	scanf("%d",&choice);
	switch(choice)
	{
	case 1:createlinkedlist(&first);
		break;
	case 2:displaylinkedlist(first);
		break;
	case 3:primenumber(first);
		break;
	}
	}while(choice!=4);
	printf("Thank You");
}